<?php

require_once "../../../vendor/autoload.php";

$object = new \Helper\Controller\Classes\Helper();

echo $object->callAction();