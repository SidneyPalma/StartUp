<?php

namespace AppAnest\Cache;

use AppAnest\Model\contract as Model;

class contract extends \Smart\Data\Cache {

}