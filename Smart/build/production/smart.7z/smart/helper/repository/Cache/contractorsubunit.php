<?php

namespace AppAnest\Cache;

use AppAnest\Model\contractorsubunit as Model;

class contractorsubunit extends \Smart\Data\Cache {

}