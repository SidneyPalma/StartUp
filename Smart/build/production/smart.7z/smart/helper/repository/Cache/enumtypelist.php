<?php

namespace AppAnest\Cache;

use AppAnest\Model\enumtypelist as Model;

class enumtypelist extends \Smart\Data\Cache {

}