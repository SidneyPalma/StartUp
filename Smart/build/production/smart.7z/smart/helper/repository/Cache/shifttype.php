<?php

namespace AppAnest\Cache;

use AppAnest\Model\shifttype as Model;

class shifttype extends \Smart\Data\Cache {

}