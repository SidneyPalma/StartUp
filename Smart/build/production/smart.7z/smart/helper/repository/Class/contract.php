<?php

require_once '../../vendor/autoload.php';

$object = new \AppAnest\Coach\contract();

echo $object->callAction();