<?php

require_once '../../vendor/autoload.php';

$object = new \AppAnest\Coach\contractorsubunit();

echo $object->callAction();