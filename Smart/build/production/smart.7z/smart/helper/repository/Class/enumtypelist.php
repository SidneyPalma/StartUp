<?php

require_once '../../vendor/autoload.php';

$object = new \AppAnest\Coach\enumtypelist();

echo $object->callAction();