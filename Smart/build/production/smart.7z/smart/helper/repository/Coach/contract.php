<?php

namespace AppAnest\Coach;

class contract extends \Smart\Common\Coach {

    /**
     * @var \AppAnest\Model\contract $model
     */
    public $model = '\AppAnest\Model\contract';

}