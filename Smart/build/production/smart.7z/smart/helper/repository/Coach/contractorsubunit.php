<?php

namespace AppAnest\Coach;

class contractorsubunit extends \Smart\Common\Coach {

    /**
     * @var \AppAnest\Model\contractorsubunit $model
     */
    public $model = '\AppAnest\Model\contractorsubunit';

}