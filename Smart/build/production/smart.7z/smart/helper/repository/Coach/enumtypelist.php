<?php

namespace AppAnest\Coach;

class enumtypelist extends \Smart\Common\Coach {

    /**
     * @var \AppAnest\Model\enumtypelist $model
     */
    public $model = '\AppAnest\Model\enumtypelist';

}