<?php

namespace AppAnest\Coach;

class shifttype extends \Smart\Common\Coach {

    /**
     * @var \AppAnest\Model\shifttype $model
     */
    public $model = '\AppAnest\Model\shifttype';

}