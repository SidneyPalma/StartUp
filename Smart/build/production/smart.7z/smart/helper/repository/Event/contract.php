<?php

namespace AppAnest\Event;

class contract extends \Smart\Data\Event {

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function preInsert( \AppAnest\Model\contract &$model ) {

    }

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function posInsert( \AppAnest\Model\contract &$model ) {

    }

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function preUpdate( \AppAnest\Model\contract &$model ) {

    }

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function posUpdate( \AppAnest\Model\contract &$model ) {

    }

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function preDelete( \AppAnest\Model\contract &$model ) {

    }

    /**
     * @param \AppAnest\Model\contract $model
     */
    public function posDelete( \AppAnest\Model\contract &$model ) {

    }

}