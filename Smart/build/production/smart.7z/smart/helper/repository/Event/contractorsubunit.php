<?php

namespace AppAnest\Event;

class contractorsubunit extends \Smart\Data\Event {

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function preInsert( \AppAnest\Model\contractorsubunit &$model ) {

    }

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function posInsert( \AppAnest\Model\contractorsubunit &$model ) {

    }

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function preUpdate( \AppAnest\Model\contractorsubunit &$model ) {

    }

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function posUpdate( \AppAnest\Model\contractorsubunit &$model ) {

    }

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function preDelete( \AppAnest\Model\contractorsubunit &$model ) {

    }

    /**
     * @param \AppAnest\Model\contractorsubunit $model
     */
    public function posDelete( \AppAnest\Model\contractorsubunit &$model ) {

    }

}