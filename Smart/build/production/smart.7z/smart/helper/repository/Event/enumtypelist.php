<?php

namespace AppAnest\Event;

class enumtypelist extends \Smart\Data\Event {

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function preInsert( \AppAnest\Model\enumtypelist &$model ) {

    }

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function posInsert( \AppAnest\Model\enumtypelist &$model ) {

    }

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function preUpdate( \AppAnest\Model\enumtypelist &$model ) {

    }

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function posUpdate( \AppAnest\Model\enumtypelist &$model ) {

    }

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function preDelete( \AppAnest\Model\enumtypelist &$model ) {

    }

    /**
     * @param \AppAnest\Model\enumtypelist $model
     */
    public function posDelete( \AppAnest\Model\enumtypelist &$model ) {

    }

}