<?php

namespace AppAnest\Event;

class shifttype extends \Smart\Data\Event {

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function preInsert( \AppAnest\Model\shifttype &$model ) {

    }

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function posInsert( \AppAnest\Model\shifttype &$model ) {

    }

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function preUpdate( \AppAnest\Model\shifttype &$model ) {

    }

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function posUpdate( \AppAnest\Model\shifttype &$model ) {

    }

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function preDelete( \AppAnest\Model\shifttype &$model ) {

    }

    /**
     * @param \AppAnest\Model\shifttype $model
     */
    public function posDelete( \AppAnest\Model\shifttype &$model ) {

    }

}